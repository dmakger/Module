package com.example.clicker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Shop extends AppCompatActivity {

    private TextView valueText;
    private int value;
    private Button finazipButton;
    private Button beerButton;
    private Button dragonFruitButton;

    private static final int VALUE_FINAZIP = 1000;
    private static final int VALUE_BEER = 2000;
    private static final int VALUE_DRAGON_FRUIT = 5000;

    private int power;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        valueText = findViewById(R.id.value_text);

        finazipButton = findViewById(R.id.finazip);
        beerButton = findViewById(R.id.beer);
        dragonFruitButton = findViewById(R.id.dragon_fruit);

        finazipButton.setText(String.valueOf(VALUE_FINAZIP));
        beerButton.setText(String.valueOf(VALUE_BEER));
        dragonFruitButton.setText(String.valueOf(VALUE_DRAGON_FRUIT));

        Intent intent = getIntent();
        value = Integer.parseInt(intent.getStringExtra("value"));
        valueText.setText("Value: " + value);

        setStateButton();

        power = intent.getIntExtra("power", 1);
    }

    private void setStateButton() {
        finazipButton.setEnabled(true);
        beerButton.setEnabled(true);
        dragonFruitButton.setEnabled(true);

        if (value < VALUE_FINAZIP) {
            finazipButton.setEnabled(false);
        } if (value < VALUE_BEER) {
            beerButton.setEnabled(false);
        } if (value < VALUE_DRAGON_FRUIT) {
            dragonFruitButton.setEnabled(false);
        }
    }

    public void onClickBack(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("value", String.valueOf(value));
        intent.putExtra("power", power);
        startActivity(intent);
    }

    public void onClickFinazip(View view) {
        value -= VALUE_FINAZIP;
        System.out.println(value);
        valueText.setText("Value: "+ value);
        power += 2;
        setStateButton();
    }

    public void onClickBeer(View view) {
        value -= VALUE_BEER;
        valueText.setText("Value: "+ value);
        power += 5;
        setStateButton();
    }

    public void onClickDragonFruit(View view) {
        value -= VALUE_DRAGON_FRUIT;
        valueText.setText("Value: "+ value);
        power += 10;
        setStateButton();
    }
}