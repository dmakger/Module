package com.example.clicker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView valueText;

    private int wall;
    private int power;
    private int box = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        valueText = findViewById(R.id.value_text);
        wall = 1000;
        power = 100;

        Intent intent = getIntent();
        valueText.setText(intent.getStringExtra("value"));
        power = intent.getIntExtra("power", 100);


        if (valueText.getText().toString().equals("")) {
            valueText.setText("0");
        }
    }

    public void onClickButtonClicker(View view) {
        int valueInt = Integer.parseInt(valueText.getText().toString());
        int nextValueInt = valueInt+power;
        valueText.setText( String.valueOf(nextValueInt));
        box += power;
        if (box >= wall){
            ++power;
            box = 0;
        }
    }

    public void onClickOpenShop(View view) {
        Intent intent = new Intent(this, Shop.class);
        intent.putExtra("value", valueText.getText().toString());
        intent.putExtra("power", power);
        startActivity(intent);
    }
}